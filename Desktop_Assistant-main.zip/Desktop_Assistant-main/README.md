# Desktop_Assistant
Hey everyone, This is a desktop assistant that can do many things for you like opening apps and googling stuffs for you, It can play music , send emails etc. Hope you like it :)
It uses python libraries to do so.
